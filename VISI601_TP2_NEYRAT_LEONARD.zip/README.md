NEYRAT Juliette 
LEONARD Simon 
CMI INFO L3 
TP2


Nous en sommes à la question :
    II.4 Diffusion comme minimisation d’une fonctionnelle
